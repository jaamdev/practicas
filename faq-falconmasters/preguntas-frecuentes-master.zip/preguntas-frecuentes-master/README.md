# Crea una Página de Preguntas Frecuentes con Filtros | HTML, CSS y Javascript
### [Tutorial: https://youtu.be/HOezqHXVVxA](https://youtu.be/HOezqHXVVxA)

![Crea una Página de Preguntas Frecuentes con Filtros | HTML, CSS y Javascript](https://raw.githubusercontent.com/falconmasters/preguntas-frecuentes/master/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)