# Como hacer un Banner de Cookies. La forma correcta (HTML, CSS y JS)
### [Tutorial: https://youtu.be/45-nGXheXwc](https://youtu.be/45-nGXheXwc)

![Como hacer un Banner de Cookies. La forma correcta (HTML, CSS y JS)](https://raw.githubusercontent.com/falconmasters/aviso-cookies/master/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)